from flask import Blueprint, request, jsonify, stream_template
from openai import OpenAI
import os
import json
import base64
import io
from PIL import Image
import PyPDF2
import docx
import re

chat_bp = Blueprint('chat', __name__)

# Initialize OpenAI client with the provided API key
client = OpenAI(
    api_key="sk-abcdef1234567890abcdef1234567890abcdef12"
)

def process_file(file_data, filename):
    """Process uploaded files and extract text content"""
    try:
        # Decode base64 file data
        if file_data.startswith('data:'):
            file_data = file_data.split(',')[1]
        
        file_bytes = base64.b64decode(file_data)
        file_extension = filename.lower().split('.')[-1]
        
        if file_extension == 'pdf':
            return process_pdf(file_bytes)
        elif file_extension in ['doc', 'docx']:
            return process_docx(file_bytes)
        elif file_extension == 'txt':
            return file_bytes.decode('utf-8')
        elif file_extension in ['jpg', 'jpeg', 'png', 'gif', 'bmp']:
            return process_image(file_bytes)
        else:
            return f"Unsupported file type: {file_extension}"
    except Exception as e:
        return f"Error processing file: {str(e)}"

def process_pdf(file_bytes):
    """Extract text from PDF"""
    try:
        pdf_file = io.BytesIO(file_bytes)
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"
        return text.strip()
    except Exception as e:
        return f"Error reading PDF: {str(e)}"

def process_docx(file_bytes):
    """Extract text from DOCX"""
    try:
        doc_file = io.BytesIO(file_bytes)
        doc = docx.Document(doc_file)
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        return text.strip()
    except Exception as e:
        return f"Error reading DOCX: {str(e)}"

def process_image(file_bytes):
    """Process image for analysis"""
    try:
        # Convert image to base64 for OpenAI Vision API
        image_base64 = base64.b64encode(file_bytes).decode('utf-8')
        return f"data:image/jpeg;base64,{image_base64}"
    except Exception as e:
        return f"Error processing image: {str(e)}"

def detect_image_generation_request(message):
    """Detect if user wants to generate an image"""
    image_keywords = [
        'generate an image', 'create an image', 'make an image', 'draw', 'generate a picture',
        'create a picture', 'make a picture', 'generate art', 'create art', 'make art',
        'generate a photo', 'create a photo', 'make a photo', 'visualize', 'show me'
    ]
    
    message_lower = message.lower()
    return any(keyword in message_lower for keyword in image_keywords)

def generate_image(prompt):
    """Generate image using DALL-E"""
    try:
        response = client.images.generate(
            model="dall-e-3",
            prompt=prompt,
            size="1024x1024",
            quality="standard",
            n=1,
        )
        
        return response.data[0].url
    except Exception as e:
        print(f"Error generating image: {str(e)}")
        return None

def analyze_image_with_vision(image_data, user_message):
    """Analyze image using GPT-4 Vision"""
    try:
        response = client.chat.completions.create(
            model="gpt-4-vision-preview",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": f"Please analyze this image. User's question: {user_message}"},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": image_data
                            }
                        }
                    ]
                }
            ],
            max_tokens=1000
        )
        
        return response.choices[0].message.content
    except Exception as e:
        print(f"Error analyzing image: {str(e)}")
        return "Sorry, I couldn't analyze the image. Please try again."

@chat_bp.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400
        
        user_message = data['message']
        conversation_history = data.get('history', [])
        file_data = data.get('file')
        filename = data.get('fileName')
        
        # Process uploaded file if present
        file_content = None
        if file_data and filename:
            file_content = process_file(file_data, filename)
        
        # Check if user wants to generate an image
        if detect_image_generation_request(user_message):
            # Extract the image description from the message
            image_prompt = user_message
            # Clean up the prompt
            for keyword in ['generate an image of', 'create an image of', 'make an image of', 'draw', 'generate', 'create', 'make']:
                image_prompt = re.sub(rf'\b{keyword}\b', '', image_prompt, flags=re.IGNORECASE).strip()
            
            image_url = generate_image(image_prompt)
            if image_url:
                return jsonify({
                    'success': True,
                    'response': f"I've generated an image for you: {image_prompt}",
                    'type': 'image',
                    'imageUrl': image_url
                })
            else:
                return jsonify({
                    'success': True,
                    'response': "Sorry, I couldn't generate the image. Please try again with a different description."
                })
        
        # Prepare messages for OpenAI API
        messages = [
            {"role": "system", "content": "You are Flare AI, a helpful and intelligent assistant. You can chat, analyze images, process documents, and help with various tasks. You are friendly, knowledgeable, and always ready to help users."}
        ]
        
        # Add conversation history
        for msg in conversation_history:
            if not msg.get('text'):
                continue
            messages.append({
                "role": "user" if msg.get('isUser') else "assistant",
                "content": msg.get('text', '')
            })
        
        # Handle file content
        if file_content:
            if filename.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp')):
                # Image analysis
                analysis = analyze_image_with_vision(file_content, user_message)
                return jsonify({
                    'success': True,
                    'response': analysis
                })
            else:
                # Text file processing
                enhanced_message = f"User uploaded a file '{filename}' with the following content:\n\n{file_content}\n\nUser's message: {user_message}"
                messages.append({"role": "user", "content": enhanced_message})
        else:
            # Add current user message
            messages.append({"role": "user", "content": user_message})
        
        # Make request to OpenAI API
        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            max_tokens=1000,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content
        
        return jsonify({
            'success': True,
            'response': ai_response
        })
        
    except Exception as e:
        print(f"Error in chat endpoint: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to get AI response. Please check your API key and try again.'
        }), 500

@chat_bp.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'service': 'Flare AI Backend'})

